﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Framework.PageObjects;
using OpenQA.Selenium;
using Framework.Driver;
//using Framework.Helpers.Interfaces;
//using Framework.Helpers.Classes;

namespace SeleniumFirst
{
    [TestClass]
    public class UnitTest1
    {
        private Pages pages;
        private MyWebDriver _driver;
        //private TestCaseHandler _testCaseHandler;
   
        [TestMethod]
        public void NavigateToLogin()
        {
            Pages.MainPage.NavigateToLogin();
            Assert.IsTrue(Pages.LoginPage.IsPageDisplayed(), "Login Page with correct header is not being displayed");

        }
        [TestMethod]
        public void NavigateToHome()
        {
            Pages.MainPage.NavigateToLogin();
            Pages.MainPage.NavigateToHome();
            Assert.IsTrue(Pages.MainPage.IsOn("CURA Healthcare Service"), "Main page with correct title is not being displayed");
        }
        [TestMethod]
        public void MakeAppointment()
        {
            //_testCaseHandler.Invoke<Action>(() =>
            //{
            //    //method steps
            //});

            Pages.MainPage.MakeAppointment();
            Pages.LoginPage.Login();
            Pages.AppointmentPage.SelectFacility("Tokyo CURA Healthcare Center");
            Pages.AppointmentPage.ApplyForHospitalReadMissions(true);
            Pages.AppointmentPage.SelectHealthCareProgram("Medicaid");
            Pages.AppointmentPage.SelectVisitDate("22/05/2018");
            Pages.AppointmentPage.EnterComment("This is a test");
            //Now we have to book the appointment before we assert the appointment is confirmed
            Assert.IsTrue(Pages.SummaryPage.IsPageDisplayed(), "Appointment Confirmation is not displayed; appointment not booked");

        }
        //[TestMethod]
        //public void MakeAppointment_WrappedTestCaseHandler()
        //{
        //    _testCaseHandler.Invoke<Action>(() =>
        //    {
        //        Pages.MainPage.MakeAppointment();
        //        Pages.LoginPage.Login();
        //        Pages.AppointmentPage.SelectFacility("Tokyo CURA Healthcare Center");
        //        Pages.AppointmentPage.ApplyForHospitalReadMissions(true);
        //        Pages.AppointmentPage.SelectHealthCareProgram("Medicaid");
        //        Pages.AppointmentPage.SelectVisitDate("22/05/2018");
        //        Pages.AppointmentPage.EnterComment("This is a test");
        //        Now we have to book the appointment before we assert the appointment is confirmed
        //        Assert.IsTrue(Pages.SummaryPage.IsPageDisplayed(), "Appointment Confirmation is not displayed; appointment not booked");
        //    });

        //}

        [TestInitialize]
        public void Setup()
        {
            MyWebDriver driver = new MyWebDriver();
            driver.GetDriver();
            _driver = driver;
            //_testCaseHandler = new TestCaseHandler(_driver);

                //.Driver;
        }
        [TestCleanup]
        public void Teardown()
        {
            _driver.Quit();
        }

        public Pages Pages
        {
            get
            {
                pages = new Pages(_driver);
                return pages;
            }
        }

    }
}
