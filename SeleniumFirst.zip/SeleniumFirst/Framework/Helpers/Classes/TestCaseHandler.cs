﻿using Framework.Driver;
using Framework.Helpers.Interfaces;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Framework.Helpers.Classes
{
    public class TestCaseHandler :ITestCaseHandler
    {
        IWebDriver _driver;
        public TestCaseHandler(MyWebDriver driver)
        {
            _driver = driver;
        }

        public void Invoke<T>(Action testCase)
        {
            Invoke(testCase);
        }
        public void Invoke(Action testStep)
        {
            try
            {
                testStep();
            }
            catch (NoSuchElementException ex)
            {
                throw new Exception(string.Format(ex.Message));

            }
            catch(ElementNotVisibleException ex)
            {
                throw new Exception(string.Format(ex.Message));
            }
            catch (ElementNotSelectableException ex)
            {
                throw new Exception(string.Format(ex.Message));
            }
            catch (InvalidElementStateException ex)
            {
                throw new Exception(string.Format(ex.Message));
            }
            catch (TimeoutException ex)
            {
                throw new Exception(string.Format(ex.Message));
            }
            catch (WebDriverException ex)
            {
                throw new Exception(string.Format(ex.Message));
            }


        }
    }
}
